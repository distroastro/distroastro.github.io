function readCookie(str) {
  var cookieString = document.cookie;
  if (cookieString) {
    var cookies = cookieString.split("; ");
    for (var idx in (cookies)) {
      var cookie = cookies[idx].toString().split("=");
      if (cookie[0] == str) {
        var cookieValue = unescape(cookie[1]);
        return cookieValue;
      }
    }
  }
  return null;
}

document.insertHTML = function(str) {
  if (document.createElementNS) {
    var pos = document;
    var spanElement = document.createElementNS("http://www.w3.org/1999/xhtml", "span");
    spanElement.innerHTML = str;
    while (pos.lastChild && pos.lastChild.nodeType == 1) {
      pos = pos.lastChild;
    }
    pos.parentNode.appendChild(spanElement);
  }
  else {
    document.write(str);
  }
}

document.insertHTML('<link id="style" rel="stylesheet" type="text/css" />');

var styleElement = document.getElementById("style");
if (readCookie("style") == "nightvision") {
  styleElement.href = "link/general-nightvision.css";
}
else {
  styleElement.href = "link/general-normal.css";
}
